/*
	Secuinside 2013 CTF qualifying round.
	LOCALONLY SERVICE challenge.

	gcc -o a a.c --no-stack-protector -z execstack
*/

#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <string.h> 
#include <sys/types.h> 
#include <netinet/in.h> 
#include <sys/socket.h> 
#include <sys/wait.h> 
#include <stdarg.h>
#include "md5.c"

#define	MYPORT	3132

int msend(int sockfd, const char *format, ...)
{
	char buf[2048];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 2048, format, ap);
	va_end(ap);

	return send(sockfd, buf, strlen(buf), 0);
}

void welcome_msg(int sockfd)
{
        msend(sockfd, "\n================================================\n");
        msend(sockfd, "WELCOME TO THE MD5 HASH GENERATING SERVICE!\n");
        msend(sockfd, "================================================\n\n");
}

int mrecv(int sockfd, char *data)
{
	int len;
	len = recv(sockfd, data, 1024, 0);
	
	// \n
	if(data[len-1] == '\n'){
		data[len-1] = 0;
		len--;
	}

	if(data[len-1] == '\r'){
		data[len-1] = 0;
		len--;
	}

	return len;
}

void do_md5(int sockfd, char *str)
{
        md5_state_t state;
        md5_byte_t digest[16];
        char hex_output[16*2 + 1];
        int di;

        md5_init(&state);
        md5_append(&state, (const md5_byte_t *)str, strlen(str));
        md5_finish(&state, digest);

        for (di = 0; di < 16; ++di)
                sprintf(hex_output + di * 2, "%02x", digest[di]);

	msend(sockfd, "%s\n", hex_output);
}

void md5(int sockfd)
{
	char data[80];

	msend(sockfd, ":: md5 hash generator ::\n");
	msend(sockfd, "(type 'q' to quit)\n\n");

	while(1){
		msend(sockfd, "> ");
		if(mrecv(sockfd, data) <= 0)
			break;

		printf("received : %s\n", data);
		fflush(stdout);

		if(strcmp(data, "q") == 0){
			msend(sockfd, "\ngoodbye!\n");
			return;
		}

		do_md5(sockfd, data);
	}
}

int check_ip(char *szIP)
{
	if(strcmp(szIP, "127.0.0.1") != 0)
		return 0;
	else
		return 1;
}

int main(int argc, char *argv[])
{
	int server_fd, client_fd;

	struct sockaddr_in my_addr;    /* my address information */
	struct sockaddr_in their_addr; /* connector's address information */
	int sin_size;
	char cmd[1024];


	if(argc < 2 ){
		printf("usage : %s port\n", argv[0]);
		return 0;
	}

	if((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket");
		exit(1);
	}


	my_addr.sin_family = AF_INET;         
	my_addr.sin_port = htons(atoi(argv[1]));     
	my_addr.sin_addr.s_addr = INADDR_ANY; 
	bzero(&(my_addr.sin_zero), 8);        

	int option=1;
	setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(int));

	if (bind(server_fd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1){
		perror("bind");
		exit(1);
	}

	if (listen(server_fd, 100) == -1) {
		perror("listen");
		exit(1);
	}	

	printf("[+] Ready for service\n");
	while(1) { 
		sin_size = sizeof(struct sockaddr_in);
		if ((client_fd = accept(server_fd, (struct sockaddr *)&their_addr, \
                                                          &sin_size)) == -1) {
        		perror("accept");
			continue;
		}

		printf("server: got connection from %s\n", (char *)inet_ntoa(their_addr.sin_addr));

		if (fork() == 0) {
        		// banner
			welcome_msg(client_fd);
		
			if(check_ip((char *)inet_ntoa(their_addr.sin_addr)) == 0)
			{
				msend(client_fd, "[!] Sorry, only 127.0.0.1 is allowed to this service for security reason..\n");
				exit(-1);
			}

			md5(client_fd);
			return 0;
		}
		close(client_fd);  /* parent doesn't need this */
		while(waitpid(-1,NULL,WNOHANG) > 0); /* clean up child processes */
        }
}

