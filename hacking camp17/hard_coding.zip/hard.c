#include "hard.h"

void hard_rol(unsigned char * str)
{
	int len = 0;

	len = strlen(str);	
	for(int i=0;i<len;i++)
	{
		str[i] = (str[i] << (len % 8)) | (str[i] >> ((8 - (len % 8))) & 0xff);
	}
}

void hard_xor(unsigned char * str, unsigned char * key)
{
	int str_len, key_len;
	
	str_len = strlen(str);
	key_len = strlen(key);

	for(int i=0;i<str_len;i++)
	{
		str[i] = (str[i] | key[i % key_len]) & (256 + ~(str[i] & key[i % key_len]));
	}
}

