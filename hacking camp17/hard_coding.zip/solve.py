#flag : hard_coding_is_very_fun_fun
def ROR(data, shift, size=32):
    shift %= size
    body = data >> shift
    remains = (data << (size - shift)) - (body << size)
    return (body + remains)

enc = map(lambda x : int(x,16), ['1a', '6e', 'e0', '7a', '9f', '68', '5', '2', '6a', '2a', '5e', '89', '12', 'fe', '89', 'cd', 'a', 'b2', '92', '9f', '40', 'f2', '16', '89', '4d', '8a', '52'])
key = map(ord, "YesYes~!!")
flag = ""

for i in range(0, len(enc)):
	t = enc[i] ^ key[i % len(key)]
	flag += chr(ROR(t, len(enc) % 8, 8) & 0xff)

print flag
