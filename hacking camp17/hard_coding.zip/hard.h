#include <stdio.h>
#include <stdlib.h>

void hard_rol(unsigned char * str);
void hard_xor(unsigned char * str, unsigned char * key);
