#include "hard.h"

#define HARD_CODE "YesYes~!!"

void enc(unsigned char * str);

void main()
{
	unsigned char check[100], user_input[100];
	unsigned char flag[]= "\x1a\x6e\xe0\x7a\x9f\x68\x05\x02\x6a\x2a\x5e\x89\x12\xfe\x89\xcd\x0a\xb2\x92\x9f\x40\xf2\x16\x89\x4d\x8a\x52";
	
	printf("Are you a hard programmer?\n");
	scanf("%s", check);
	if(strncmp(HARD_CODE, check, strlen(HARD_CODE)))
	{
		printf("You are not a hard programmer.\n");
		printf("I'm looking for a hard programmer :-)\n");
		return ;
	}
	else
	{
		printf("You're a hard programmer!\n");
		printf("I need your help.\n");
		printf("Please analyze the program and enter value that decoded the following values\n");
		printf("> ");
		scanf("%s", user_input);
		enc(user_input);
		if(memcmp(user_input, flag, strlen(flag)) == 0)
		{
			printf("Thank you!\n You're good engineer!\n");
			return;
		}
		else
		{
			printf("I don't think it's the right answer. :-(\n");
			return;
		}
			
	}
	
	
}

void enc(unsigned char * str)
{
	hard_rol(str);
	hard_xor(str, HARD_CODE);
}
