if __name__ == "__main__":
    print 'L'
    exit(1)